name = input("Enter your name ")
age = input("Enter your age ")
for x in range(0,int(age)):
          print(x+1,"Your name is",name)
