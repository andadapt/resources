##answer = 15
##userentry=""
##while answer != userentry:
##    userentry = int(input("Enter a number between 1 and 20"))
##print("Well done you correctly guessed the number")

##Extension 1 - counting the number of attempts
##answer = 15
##attempts= 0
##userentry=""
##while answer != userentry:
##    userentry = int(input("Enter a number between 1 and 20 "))
##    attempts=attempts+1
##print("Well done you correctly guessed the number it took you",attempts,"attempts")

##Extension 2 - adding validation
answer = 15
attempts= 1
userentry=input("Enter a number between 1 and 20 ")
if len(userentry)==0:
    print("Please enter a number")
else:
    userentry=int(userentry)
    while answer != userentry:
        userentry = int(input("Enter a number between 1 and 20 "))
        attempts=attempts+1
    print("Well done you correctly guessed the number it took you",attempts,"attempts")
