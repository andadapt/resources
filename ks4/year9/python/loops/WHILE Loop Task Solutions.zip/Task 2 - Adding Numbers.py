##Extension
##total = 0
##entries = 0
##another = "Y"
##while another == "Y":
##    number = int(input("Enter a number to add to the total: "))
##    total = total + number
##    entries = entries + 1
##    another = input("Do you want to enter another number? Y/N ")
##average = total / entries
##print("You entered",entries,"numbers which came to a total of",total,"the average was",average)
total = 0
another = "Y"
while another == "Y":
    number = int(input("Enter a number to add to the total: "))
    total = total + number
    another = input("Do you want to enter another number? Y/N ")
print("The total of your numbers was",total)

